package com.example.vinaypratap.rgptaskapp;


import retrofit.Callback;
import retrofit.http.GET;

public interface RequestBuilder {
    @GET("/")
    public void getData(Callback<String> response);
}
