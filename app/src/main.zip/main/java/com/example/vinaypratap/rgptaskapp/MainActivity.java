package com.example.vinaypratap.rgptaskapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.RetrofitError;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mTextResult;
    private EditText mInputTimeInt;
    private Button mStartRequest, mEndRequest;
    private ArrayList<String> list = new ArrayList<>(Constants.MAX_SIZE);
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

    }

    private void init() {
        mTextResult = (TextView) findViewById(R.id.text_result);
        mInputTimeInt = (EditText) findViewById(R.id.input_timeinterval);
        mStartRequest = (Button) findViewById(R.id.start_request);
        mEndRequest = (Button) findViewById(R.id.end_request);
        mStartRequest.setOnClickListener(this);
        mEndRequest.setOnClickListener(this);
    }


    private void startRecurTimer(int timeInterVal) {
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                ResponseListener.cancelAll();
                RequestBuilder requestBuilder = ClientGenerator.createService(RequestBuilder.class);
                requestBuilder.getData(new ResponseListener<String>("myRequest") {
                    @Override
                    public void onSuccess(String s) {
                        mTextResult.setText("[" + s + "]");
                        addToList(s);
                    }

                    @Override
                    public void onError(RetrofitError error) {
                        if (error.isNetworkError()) {
                            if (error.getCause() instanceof ConnectException) {
                                Toast.makeText(MainActivity.this, R.string.toast_error_no_network, Toast.LENGTH_SHORT).show();
                                if (list.size() != 0)
                                    mTextResult.setText(list.toString());
                                else
                                    mTextResult.setText(R.string.nothing_to_show);

                            } else if (error.getCause() instanceof SocketTimeoutException) {
                                //handle time out here
                                Toast.makeText(MainActivity.this, R.string.toast_error_time_out, Toast.LENGTH_SHORT).show();
                                if (list.size() >= 3)
                                    mTextResult.setText(list.subList(0, 3).toString());
                                else if (list.size() != 0)
                                    mTextResult.setText(list.toString());
                                else
                                    mTextResult.setText(R.string.nothing_to_show);
                            }
                        } else {
                            Toast.makeText(MainActivity.this, R.string.toast_error, Toast.LENGTH_SHORT).show();

                        }
                    }
                });

            }
        };
        timer = new Timer();
        timer.scheduleAtFixedRate(task, 0, timeInterVal);
    }

    private void addToList(String s) {
        if (list.size() == Constants.MAX_SIZE)
            list.remove(Constants.MAX_SIZE - 1);
        list.add(0, s);
    }

    private void endReq() {
        if (timer != null)
            timer.cancel();
        ResponseListener.cancelAll();
    }

    @Override
    protected void onStop() {
        endReq();
        super.onStop();
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.start_request:
                if (TextUtils.isEmpty(mInputTimeInt.getText().toString())) {
                    Toast.makeText(MainActivity.this, R.string.toast_empty_field, Toast.LENGTH_SHORT).show();
                } else {
                    endReq(); // if already running clean it and restart startrecurTimer with new value
                    String timeIntVal = mInputTimeInt.getText().toString();
                    int timeIntervalMiliSec = Integer.valueOf(timeIntVal);
                    startRecurTimer(timeIntervalMiliSec * 1000);
                    mInputTimeInt.setText(null);
                    Utility.hideKeyboard(view, MainActivity.this);
                }
                break;
            case R.id.end_request:
                endReq();
                break;
        }

    }
}
