package com.example.vinaypratap.rgptaskapp;

/**
 * Created by vinaypratap on 29/3/16.
 */
public class Constants {

    public static final String API_BASE_URL = "http://54.152.115.182:9000/";
    public static final int MAX_SIZE = 5;
}
